from fermipy.gtanalysis import GTAnalysis
import os

os.environ['DATADIR']='..'

gta = GTAnalysis('config.yaml')
gta.setup(overwrite=True)
gta.write_roi('fit0')
gta.optimize()
gta.write_roi('fit1')
gta.lightcurve('3FGL J1555.7+1111',nbins=2)
