from fermipy.gtanalysis import GTAnalysis

gta = GTAnalysis('config.yaml')

gta.setup()

gta.write_roi('fit0')

gta.optimize()

gta.write_roi('fit1')

gta.free_norm('draco')
gta.free_norm('galdiff')
gta.free_norm('isodiff')

gta.fit()

gta.sed('draco')
gta.write_roi('fit2')
