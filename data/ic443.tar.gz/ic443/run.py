from fermipy.gtanalysis import GTAnalysis
import numpy as np

gta = GTAnalysis('config.yaml')

gta.setup(overwrite=True)
gta.optimize()
gta.sed('ic443')
gta.extension('ic443',width=np.linspace(0.25,0.35,21).tolist())
gta.write_roi('ext_fit',make_residuals=True)

