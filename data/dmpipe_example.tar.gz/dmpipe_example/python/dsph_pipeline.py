#!/usr/bin/env python
#
from __future__ import absolute_import, division, print_function

import sys

from dmpipe.pipeline import Pipeline

ttype = 'dSphs'
configfile = 'config/master_%s.yaml' % ttype

pipe = Pipeline(linkname=ttype)

pipe.preconfigure(configfile)
pipe.update_args(dict(config=configfile))


